Makefile commands:

make clean

make input_one

make input_two

make input_three 

They all take the input from the corresponding file and write it to the file "output".