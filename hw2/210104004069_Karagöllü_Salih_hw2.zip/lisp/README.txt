Hello,

To run the code, here are the instructions:

Go into sbcl: sbcl
Load the file: (load "gpp_lexer.lisp.lisp")
To start the interpreter, type: (gppinterpreter "filename")
